public class First {
    /**
     * @param args
     */
    public static void main(String[] args) {
        System.out.println("Hello World!");
        System.out.println("Привет, Мир!");
    }
} 